const el = (id) => document.getElementById(id);
const DIAS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
const chave = (d) => d.toLocaleDateString('sv');

const FRASES = [
  'O teto que você mesmo definiu. Amanhã tem mais.',
  'Acabou o crédito do dia. O contador zera à meia-noite.',
  'Você chegou onde combinou consigo mesmo chegar.'
];

// --- contagem até a virada do dia -----------------------------------------

function pintarRelogio() {
  el('agora').textContent = new Date().toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit'
  });

  const meiaNoite = new Date();
  meiaNoite.setHours(24, 0, 0, 0);
  const resta = meiaNoite - Date.now();

  const h = Math.floor(resta / 3600000);
  const m = Math.floor((resta % 3600000) / 60000);
  const s = Math.floor((resta % 60000) / 1000);
  const pad = (n) => String(n).padStart(2, '0');

  el('relogio').innerHTML =
    'O contador zera em <b>' + h + ':' + pad(m) + ':' + pad(s) + '</b>';
}

pintarRelogio();
setInterval(pintarRelogio, 1000);

// --- números do dia e da semana -------------------------------------------

chrome.storage.local.get(['config', 'uso', 'historico'], ({ config, uso, historico }) => {
  const cfg = config || {};
  const limite = Number(cfg.limiteDiario || 0);
  const hoje = chave(new Date());
  const segundosHoje = uso && uso.dia === hoje ? uso.segundos : 0;
  const minutos = Math.floor(segundosHoje / 60);

  el('assistido').textContent = String(minutos);
  el('unidade').textContent = minutos === 1 ? 'minuto hoje' : 'minutos hoje';
  el('frase').textContent = FRASES[Math.floor(Math.random() * FRASES.length)];

  // trilha: parte cheia até o teto, excesso em teal depois dele
  const excedente = Math.max(0, minutos - limite);
  const total = Math.max(limite, minutos) || 1;
  el('cheio').style.width = (Math.min(minutos, limite) / total) * 100 + '%';
  el('excesso').style.width = (excedente / total) * 100 + '%';

  el('rotuloTeto').textContent = 'teto de ' + limite + ' min';
  el('rotuloSaldo').textContent = excedente
    ? excedente + ' min além'
    : 'no limite exato';

  // --- barras dos sete dias ---
  const registro = historico || {};
  const dias = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    dias.push({
      rotulo: DIAS[d.getDay()],
      min: Math.floor((registro[chave(d)] || 0) / 60),
      hoje: i === 0
    });
  }

  const teto = Math.max(limite, ...dias.map((d) => d.min), 1);

  el('barras').innerHTML = dias
    .map(
      (d) =>
        `<div class="col${d.hoje ? ' hoje' : ''}" title="${d.min} min">
           <div class="haste" style="height:${(d.min / teto) * 100}%"></div>
           <div class="dia">${d.rotulo}</div>
         </div>`
    )
    .join('');

  // linha tracejada marcando o teto sobre as barras
  if (limite) {
    const corte = el('corte');
    corte.hidden = false;
    corte.style.top = 84 - (limite / teto) * 84 + 'px';
  }
});

// --- ações ----------------------------------------------------------------

el('fechar').addEventListener('click', () => window.close());

el('foco').addEventListener('click', async () => {
  const meiaNoite = new Date();
  meiaNoite.setHours(24, 0, 0, 0);
  const { config } = await chrome.storage.local.get('config');
  await chrome.storage.local.set({
    config: { ...(config || {}), focoAte: meiaNoite.getTime() }
  });
  el('foco').textContent = 'Travado até a meia-noite';
  el('foco').disabled = true;
});
