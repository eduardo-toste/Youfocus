const el = (id) => document.getElementById(id);
const DIAS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];

const EXPLICA = {
  livre: 'YouTube aberto, com os ajustes abaixo valendo.',
  fechado: 'Nada abre — nem youtu.be, nem app móvel, nem versão music, nem player embutido em outro site.'
};

const ler = async () => (await chrome.storage.local.get('config')).config || {};
async function gravar(mud) {
  await chrome.storage.local.set({ config: { ...(await ler()), ...mud } });
  pintar();
}

// --- semana ---------------------------------------------------------------

el('semana').innerHTML = DIAS.map(
  (d, i) => `<button type="button" data-dia="${i}" aria-pressed="false">${d}</button>`
).join('');

el('semana').addEventListener('click', async (ev) => {
  const alvo = ev.target.closest('button');
  if (!alvo) return;
  const dia = Number(alvo.dataset.dia);
  const cfg = await ler();
  const dias = new Set(cfg.dias || []);
  dias.has(dia) ? dias.delete(dia) : dias.add(dia);
  gravar({ dias: [...dias].sort() });
});

// --- modo -----------------------------------------------------------------

el('modos').addEventListener('click', (ev) => {
  const alvo = ev.target.closest('button');
  if (alvo) gravar({ modo: alvo.dataset.modo });
});

// --- foco -----------------------------------------------------------------

function avisar(t) {
  el('aviso').textContent = t;
  el('aviso').hidden = !t;
}

document.querySelectorAll('.rapidos button').forEach((b) =>
  b.addEventListener('click', () => gravar({ focoAte: Date.now() + Number(b.dataset.min) * 60000 }))
);

el('minutos').addEventListener('input', () => avisar(''));
el('ateHora').addEventListener('input', () => avisar(''));

el('irMin').addEventListener('click', () => {
  const m = parseInt(el('minutos').value, 10);
  if (!m || m < 1) return avisar('Digite quantos minutos, a partir de 1.');
  if (m > 1440) return avisar('O teto é 1440 minutos, ou seja, um dia.');
  gravar({ focoAte: Date.now() + m * 60000 });
});

el('irHora').addEventListener('click', () => {
  if (!el('ateHora').value) return avisar('Escolha um horário primeiro.');
  const [h, m] = el('ateHora').value.split(':').map(Number);
  const alvo = new Date();
  alvo.setHours(h, m, 0, 0);
  if (alvo.getTime() <= Date.now()) alvo.setDate(alvo.getDate() + 1);
  gravar({ focoAte: alvo.getTime() });
});

el('encerrar').addEventListener('click', () => gravar({ focoAte: 0 }));

// --- ajustes --------------------------------------------------------------

['semShorts', 'semRecomendados', 'semComentarios', 'portao', 'horario'].forEach((id) =>
  el(id).addEventListener('change', () => gravar({ [id]: el(id).checked }))
);

el('limite').addEventListener('change', () =>
  gravar({ limiteDiario: Math.max(0, parseInt(el('limite').value, 10) || 0) })
);

['inicio', 'fim'].forEach((id) =>
  el(id).addEventListener('change', () => gravar({ [id]: el(id).value }))
);

// --- desenhar -------------------------------------------------------------

const hora = (ms) =>
  new Date(ms).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

async function pintar() {
  const cfg = await ler();
  const foco = cfg.focoAte && Date.now() < cfg.focoAte;

  document.querySelectorAll('#modos button').forEach((b) =>
    b.setAttribute('aria-pressed', String(b.dataset.modo === (cfg.modo || 'livre')))
  );
  el('explica').textContent = foco
    ? 'Sessão de foco em andamento: o YouTube está fechado até ela acabar.'
    : EXPLICA[cfg.modo || 'livre'];

  el('ocioso').hidden = !!foco;
  el('andamento').hidden = !foco;
  if (foco) {
    const resta = cfg.focoAte - Date.now();
    const h = Math.floor(resta / 3600000);
    const m = Math.ceil((resta % 3600000) / 60000);
    el('contagem').textContent = h ? `${h}h${String(m).padStart(2, '0')}` : `${m} min`;
    el('ate').textContent = 'até às ' + hora(cfg.focoAte);
  }

  el('semShorts').checked = cfg.semShorts !== false;
  el('semRecomendados').checked = cfg.semRecomendados !== false;
  el('semComentarios').checked = !!cfg.semComentarios;
  el('portao').checked = cfg.portao !== false;
  el('horario').checked = !!cfg.horario;
  el('caixaHorario').hidden = !cfg.horario;
  el('inicio').value = cfg.inicio || '09:00';
  el('fim').value = cfg.fim || '18:00';
  el('limite').value = String(cfg.limiteDiario || 0);

  const dias = cfg.dias || [];
  document.querySelectorAll('#semana button').forEach((b) =>
    b.setAttribute('aria-pressed', String(dias.includes(Number(b.dataset.dia))))
  );

  const { uso } = await chrome.storage.local.get('uso');
  const hojeStr = new Date().toLocaleDateString('sv');
  const min = uso && uso.dia === hojeStr ? Math.floor(uso.segundos / 60) : 0;
  const limite = Number(cfg.limiteDiario || 0);

  el('hoje').textContent = limite ? `hoje ${min}/${limite} min` : `hoje ${min} min`;
  el('barraUso').style.width = limite ? Math.min(100, (min / limite) * 100) + '%' : '0';
}

pintar();
setInterval(pintar, 15000);
