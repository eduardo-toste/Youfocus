// ---------------------------------------------------------------------------
// Youfocus — service worker
//
// Regra de ouro deste arquivo: os modos sao EXCLUSIVOS. Cada modo emite o seu
// proprio conjunto de regras e nenhum outro. Foi a mistura de regras de
// bloqueio com regras de redirecionamento que deixava o YouTube abrir antes.
// ---------------------------------------------------------------------------

// Todo endereco por onde o YouTube entra: encurtador, app movel, versao sem
// cookie e os frontends alternativos.
const HOSTS = [
  'youtube.com',
  'm.youtube.com',
  'music.youtube.com',
  'youtube-nocookie.com',
  'youtu.be',
  'yewtu.be',
  'piped.video',
  'invidious.snopyta.org'
];

const DEFAULTS = {
  modo: 'livre',        // 'livre' | 'fechado'
  focoAte: 0,           // sessao iniciada agora; vence tudo enquanto durar
  horario: false,       // bloquear tambem numa faixa fixa do dia
  inicio: '09:00',
  fim: '18:00',
  dias: [1, 2, 3, 4, 5],
  limiteDiario: 0,      // minutos de video por dia; 0 desliga
  semShorts: true,      // Shorts fora do ar mesmo no modo Livre
  semRecomendados: true,
  semComentarios: false,
  portao: true          // contar ate 10 antes de abrir um video
};

async function lerConfig() {
  const { config } = await chrome.storage.local.get('config');
  return { ...DEFAULTS, ...(config || {}) };
}

// ---------------------------------------------------------------------------
// Qual modo vale agora
// ---------------------------------------------------------------------------

const emFoco = (cfg) => !!cfg.focoAte && Date.now() < cfg.focoAte;

function dentroDoHorario(cfg) {
  if (!cfg.horario) return false;
  const agora = new Date();
  if (!cfg.dias.includes(agora.getDay())) return false;

  const min = (t) => {
    const [h, m] = String(t).split(':').map(Number);
    return h * 60 + m;
  };
  const atual = agora.getHours() * 60 + agora.getMinutes();
  const i = min(cfg.inicio);
  const f = min(cfg.fim);
  return i > f ? atual >= i || atual < f : atual >= i && atual < f;
}

function tetoEstourado(cfg, uso) {
  const limite = Number(cfg.limiteDiario || 0);
  if (!limite || !uso) return false;
  const hoje = new Date().toLocaleDateString('sv');
  return uso.dia === hoje && uso.segundos >= limite * 60;
}

// devolve 'fechado' ou 'livre' — e o motivo, para a placa
function modoEfetivo(cfg, uso) {
  if (emFoco(cfg)) return { modo: 'fechado', motivo: 'foco' };
  if (dentroDoHorario(cfg)) return { modo: 'fechado', motivo: 'horario' };
  if (cfg.modo === 'fechado') return { modo: 'fechado', motivo: 'total' };
  if (tetoEstourado(cfg, uso)) return { modo: 'fechado', motivo: 'limite' };
  return { modo: 'livre', motivo: '' };
}

// ---------------------------------------------------------------------------
// Regras
// ---------------------------------------------------------------------------

const placa = (motivo) => ({
  type: 'redirect',
  redirect: {
    extensionPath: motivo === 'limite' ? '/limite.html' : '/blocked.html?motivo=' + motivo
  }
});

function regrasBloqueio(motivo) {
  const regras = [];
  let id = 1;

  for (const host of HOSTS) {
    regras.push({
      id: id++,
      priority: 1,
      action: placa(motivo),
      condition: { urlFilter: '||' + host, resourceTypes: ['main_frame'] }
    });
    regras.push({
      id: id++,
      priority: 1,
      action: { type: 'block' },
      condition: { urlFilter: '||' + host, resourceTypes: ['sub_frame'] }
    });
  }
  return regras;
}

// No modo Livre as unicas regras que existem sao as dos ajustes.
function regrasLivre(cfg) {
  const regras = [];
  let id = 1;

  if (cfg.semShorts) {
    // o rolo vertical nao abre
    regras.push({
      id: id++,
      priority: 1,
      action: placa('shorts'),
      condition: {
        regexFilter: '^https?://(www\\.|m\\.)?youtube\\.com/shorts/',
        resourceTypes: ['main_frame']
      }
    });
  }

  // youtu.be/xyz vira a pagina normal, para o portao e o contador valerem
  regras.push({
    id: id++,
    priority: 1,
    action: {
      type: 'redirect',
      redirect: { regexSubstitution: 'https://www.youtube.com/watch?v=\\1' }
    },
    condition: {
      regexFilter: '^https?://youtu\\.be/([\\w-]+)',
      resourceTypes: ['main_frame']
    }
  });

  return regras;
}

// o contador escreve a cada 10s; sem esta assinatura reescreveriamos as
// regras o tempo todo sem necessidade
let assinatura = null;

async function aplicar() {
  const cfg = await lerConfig();
  const { uso } = await chrome.storage.local.get('uso');
  const { modo, motivo } = modoEfetivo(cfg, uso);

  const novas = modo === 'fechado' ? regrasBloqueio(motivo) : regrasLivre(cfg);
  const nova = JSON.stringify(novas);

  if (nova !== assinatura) {
    assinatura = nova;
    const atuais = await chrome.declarativeNetRequest.getDynamicRules();
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: atuais.map((r) => r.id),
      addRules: novas
    });
  }

  if (emFoco(cfg)) {
    await chrome.action.setBadgeText({
      text: String(Math.ceil((cfg.focoAte - Date.now()) / 60000))
    });
    await chrome.action.setBadgeBackgroundColor({ color: '#16736b' });
  } else {
    await chrome.action.setBadgeText({ text: modo === 'fechado' ? 'off' : '' });
    await chrome.action.setBadgeBackgroundColor({ color: '#0b2733' });
  }
}

// ---------------------------------------------------------------------------
// Gatilhos
// ---------------------------------------------------------------------------

chrome.runtime.onInstalled.addListener(async () => {
  const { config } = await chrome.storage.local.get('config');
  if (!config) await chrome.storage.local.set({ config: DEFAULTS });
  chrome.alarms.create('tique', { periodInMinutes: 1 });
  aplicar();
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('tique', { periodInMinutes: 1 });
  aplicar();
});

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'tique') aplicar();
});

chrome.storage.onChanged.addListener((mud, area) => {
  if (area === 'local' && (mud.config || mud.uso)) aplicar();
});
