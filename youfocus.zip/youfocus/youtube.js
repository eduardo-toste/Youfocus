// ---------------------------------------------------------------------------
// Youfocus — ajustes dentro da pagina do YouTube
// Esconde elementos, conta o tempo assistido e segura o video por 10 segundos.
// ---------------------------------------------------------------------------

(() => {
  const CSS = `
  html.yf-sem-shorts ytd-rich-shelf-renderer[is-shorts],
  html.yf-sem-shorts ytd-reel-shelf-renderer,
  html.yf-sem-shorts ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts]),
  html.yf-sem-shorts ytd-rich-item-renderer:has(a[href^="/shorts"]),
  html.yf-sem-shorts ytd-video-renderer:has(a[href^="/shorts"]),
  html.yf-sem-shorts ytd-guide-entry-renderer:has(a[title="Shorts"]),
  html.yf-sem-shorts ytd-mini-guide-entry-renderer[aria-label="Shorts"] { display: none !important; }

  html.yf-sem-recomendados #secondary #related,
  html.yf-sem-recomendados ytd-watch-next-secondary-results-renderer,
  html.yf-sem-recomendados .ytp-endscreen-content,
  html.yf-sem-recomendados .ytp-ce-element { display: none !important; }

  html.yf-sem-comentarios ytd-comments#comments { display: none !important; }

  #yf-portao {
    position: fixed; inset: 0; z-index: 2147483647;
    background: #06171f; color: #e4f1f0;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    gap: 16px; text-align: center; padding: 32px; font-family: system-ui, sans-serif;
  }
  #yf-portao .yf-marca { font-family: ui-monospace, Menlo, monospace; font-size: 11px; letter-spacing: .2em; text-transform: uppercase; color: #8fb6b8; margin: 0; }
  #yf-portao .yf-conta { font-family: "Arial Narrow", system-ui, sans-serif; font-weight: 700; font-size: 88px; line-height: 1; color: #c6e85e; margin: 0; }
  #yf-portao .yf-frase { font-size: 16px; color: #b6d4d2; max-width: 34ch; margin: 0; }
  #yf-portao button { font: inherit; cursor: pointer; padding: 10px 22px; border-radius: 3px; border: none; background: #c6e85e; color: #06171f; }
  #yf-portao button.yf-fraco { background: transparent; color: #8fb6b8; border: 1px solid #17515c; }
  #yf-portao button[disabled] { opacity: .35; cursor: default; }
  `;

  const estilo = document.createElement('style');
  estilo.textContent = CSS;
  (document.head || document.documentElement).appendChild(estilo);

  let cfg = {};
  const ehVideo = () => location.pathname === '/watch';
  const hoje = () => new Date().toLocaleDateString('sv');

  // --- tempo assistido -----------------------------------------------------

  const PASSO = 10;

  function rodando() {
    if (!ehVideo() || document.visibilityState !== 'visible') return false;
    const v = document.querySelector('video.html5-main-video, video');
    return !!v && !v.paused && !v.ended && v.readyState > 2;
  }

  async function marcar() {
    const limite = Number(cfg.limiteDiario || 0);
    if (!limite) return;

    const dados = await chrome.storage.local.get(['uso', 'historico']);
    const uso = dados.uso && dados.uso.dia === hoje() ? dados.uso : { dia: hoje(), segundos: 0 };

    if (rodando()) {
      uso.segundos += PASSO;

      // historico dos ultimos 14 dias, para o grafico da tela de limite
      const historico = { ...(dados.historico || {}), [hoje()]: uso.segundos };
      const dias = Object.keys(historico).sort().slice(-14);
      const podado = {};
      for (const d of dias) podado[d] = historico[d];

      await chrome.storage.local.set({ uso, historico: podado });
    }

    // Quem bloqueia e o service worker, via regra de rede. Aqui so paramos o
    // video que ja estava rodando e saimos da pagina.
    if (uso.segundos >= limite * 60 && ehVideo()) {
      const v = document.querySelector('video');
      if (v) v.pause();
      location.replace(chrome.runtime.getURL('limite.html'));
    }
  }

  setInterval(() => marcar().catch(() => {}), PASSO * 1000);

  // --- portao de 10 segundos ----------------------------------------------

  const FRASES = [
    'Você veio buscar este vídeo, ou ele veio buscar você?',
    'Dez segundos. Se ainda quiser depois, é seu.',
    'O que você ia fazer antes de abrir isto?'
  ];

  let ultimo = null;

  function abrirPortao() {
    if (document.getElementById('yf-portao')) return;

    const p = document.createElement('div');
    p.id = 'yf-portao';
    p.innerHTML = `
      <p class="yf-marca">Youfocus</p>
      <p class="yf-conta" id="yf-conta">10</p>
      <p class="yf-frase">${FRASES[Math.floor(Math.random() * FRASES.length)]}</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">
        <button id="yf-seguir" disabled>Aguarde…</button>
        <button class="yf-fraco" id="yf-sair">Deixa pra lá</button>
      </div>`;
    (document.body || document.documentElement).appendChild(p);

    const segurar = setInterval(() => {
      const v = document.querySelector('video');
      if (v && !v.paused) v.pause();
    }, 300);

    let resta = 10;
    const tique = setInterval(() => {
      resta -= 1;
      const c = document.getElementById('yf-conta');
      if (c) c.textContent = String(Math.max(0, resta));
      if (resta <= 0) {
        clearInterval(tique);
        const b = document.getElementById('yf-seguir');
        if (b) { b.disabled = false; b.textContent = 'Assistir'; }
      }
    }, 1000);

    const fechar = () => { clearInterval(segurar); clearInterval(tique); p.remove(); };
    p.querySelector('#yf-seguir').addEventListener('click', fechar);
    p.querySelector('#yf-sair').addEventListener('click', () => {
      fechar();
      location.href = 'https://www.youtube.com/feed/subscriptions';
    });
  }

  function conferir() {
    if (!cfg.portao || !ehVideo()) return;
    const id = new URLSearchParams(location.search).get('v');
    if (!id || id === ultimo) return;
    ultimo = id;
    abrirPortao();
  }

  // --- configuracoes -------------------------------------------------------

  function aplicar(nova) {
    cfg = nova || {};
    const raiz = document.documentElement;

    raiz.classList.toggle('yf-sem-shorts', cfg.semShorts !== false);
    raiz.classList.toggle('yf-sem-recomendados', cfg.semRecomendados !== false);
    raiz.classList.toggle('yf-sem-comentarios', !!cfg.semComentarios);
    conferir();
  }

  chrome.storage.local.get('config', (d) => aplicar(d.config));
  chrome.storage.onChanged.addListener((m, area) => {
    if (area === 'local' && m.config) aplicar(m.config.newValue);
  });

  window.addEventListener('yt-navigate-finish', conferir);
})();
