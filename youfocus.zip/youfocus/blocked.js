const motivo = new URLSearchParams(location.search).get('motivo') || 'total';
const DIAS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
const el = (id) => document.getElementById(id);

function marcarHora() {
  el('relogio').textContent = new Date().toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit'
  });
}
marcarHora();
setInterval(marcarHora, 20000);

const hora = (ms) =>
  new Date(ms).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

chrome.storage.local.get('config', ({ config }) => {
  const cfg = config || {};

  if (motivo === 'foco') {
    el('titulo').textContent = 'em foco';
    el('nota').textContent = 'Sessão em andamento. Você mesmo apertou o botão, e não há como liberar antes da hora.';
    el('detalhe').innerHTML = 'Termina às <b>' + hora(cfg.focoAte) + '</b>';
    return;
  }

  if (motivo === 'horario') {
    el('titulo').textContent = 'fora de hora';
    el('nota').textContent = 'Este é um dos horários em que você pediu para o YouTube ficar fechado.';
    el('detalhe').innerHTML =
      'Reabre às <b>' + cfg.fim + '</b><br>' +
      (cfg.dias || []).map((d) => DIAS[d]).join(' · ') +
      ' — das ' + cfg.inicio + ' às ' + cfg.fim;
    return;
  }

  if (motivo === 'shorts') {
    el('titulo').textContent = 'sem shorts';
    el('nota').textContent =
      'O rolo vertical foi feito para você não conseguir parar. Ele está desligado nos ajustes.';
    el('detalhe').innerHTML = 'O resto do YouTube continua aberto';
    el('inscricoes').hidden = false;
    return;
  }

  el('titulo').textContent = 'fechado';
  el('nota').textContent =
    'O YouTube está no modo Fechado. Vale para o site, o app móvel, os links youtu.be e os players embutidos em outras páginas.';
  el('detalhe').innerHTML = 'Para reabrir, troque o modo no ícone da extensão';
});

el('voltar').addEventListener('click', () => {
  if (history.length > 1) history.back();
  else location.href = 'about:blank';
});

el('inscricoes').addEventListener('click', () => {
  location.href = 'https://www.youtube.com/feed/subscriptions';
});
